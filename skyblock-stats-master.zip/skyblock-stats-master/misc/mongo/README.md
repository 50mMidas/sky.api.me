mongo dump of the top 20 profiles

import via `mongorestore profileViews.bson --drop --db=sbstats`
